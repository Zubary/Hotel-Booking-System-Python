import tkinter as tk
from tkinter import messagebox, ttk
import sqlite3
import hashlib
from datetime import datetime

# Database initialization
conn = sqlite3.connect('hotel.db')
cursor = conn.cursor()

# Create tables
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL
)''')

cursor.execute('''CREATE TABLE IF NOT EXISTS bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    room_number TEXT,
    check_in TEXT,
    check_out TEXT,
    FOREIGN KEY(user_id) REFERENCES users(id)
)''')

conn.commit()


# Utility functions
def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


# GUI Application
class HotelApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Management System")
        self.current_user = None
        self.show_login()

    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()

    def show_login(self):
        self.clear_screen()
        tk.Label(self.root, text="Login", font=("Arial", 16)).pack(pady=10)

        tk.Label(self.root, text="Username").pack()
        username_entry = tk.Entry(self.root)
        username_entry.pack()

        tk.Label(self.root, text="Password").pack()
        password_entry = tk.Entry(self.root, show="*")
        password_entry.pack()

        def login_action():
            username = username_entry.get()
            password = password_entry.get()
            hashed = hash_password(password)
            cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed))
            user = cursor.fetchone()
            if user:
                self.current_user = {'id': user[0], 'username': user[1], 'role': user[3]}
                if user[3] == 'admin':
                    self.show_admin_dashboard()
                else:
                    self.show_user_dashboard()
            else:
                messagebox.showerror("Error", "Invalid credentials")

        tk.Button(self.root, text="Login", command=login_action).pack(pady=10)
        tk.Button(self.root, text="Register", command=self.show_register).pack()

    def show_register(self):
        self.clear_screen()
        tk.Label(self.root, text="Register", font=("Arial", 16)).pack(pady=10)

        tk.Label(self.root, text="Username").pack()
        username_entry = tk.Entry(self.root)
        username_entry.pack()

        tk.Label(self.root, text="Password").pack()
        password_entry = tk.Entry(self.root, show="*")
        password_entry.pack()

        tk.Label(self.root, text="Role (admin/user)").pack()
        role_entry = tk.Entry(self.root)
        role_entry.pack()

        def register_action():
            username = username_entry.get()
            password = password_entry.get()
            role = role_entry.get().lower()
            if role not in ['admin', 'user']:
                messagebox.showerror("Error", "Role must be 'admin' or 'user'")
                return
            hashed = hash_password(password)
            try:
                cursor.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)", (username, hashed, role))
                conn.commit()
                messagebox.showinfo("Success", "User registered successfully")
                self.show_login()
            except sqlite3.IntegrityError:
                messagebox.showerror("Error", "Username already exists")

        tk.Button(self.root, text="Register", command=register_action).pack(pady=10)
        tk.Button(self.root, text="Back to Login", command=self.show_login).pack()

    def show_admin_dashboard(self):
        self.clear_screen()
        tk.Label(self.root, text=f"Admin Dashboard - Welcome, {self.current_user['username']}", font=("Arial", 16)).pack(pady=10)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Generate Reports", command=self.generate_reports, width=20).pack(pady=5)
        tk.Button(button_frame, text="Logout", command=self.show_login, width=20).pack(pady=20)

    def generate_reports(self):
        self.clear_screen()
        tk.Label(self.root, text="Booking Report", font=("Arial", 16)).pack(pady=10)

        tree = ttk.Treeview(self.root, columns=("ID", "Username", "Room", "Check-in", "Check-out"), show="headings")
        tree.heading("ID", text="ID")
        tree.heading("Username", text="Username")
        tree.heading("Room", text="Room")
        tree.heading("Check-in", text="Check-in")
        tree.heading("Check-out", text="Check-out")
        tree.pack(pady=10)

        cursor.execute('''SELECT bookings.id, users.username, bookings.room_number, bookings.check_in, bookings.check_out 
                          FROM bookings JOIN users ON bookings.user_id = users.id''')
        for row in cursor.fetchall():
            tree.insert("", "end", values=row)

        tk.Button(self.root, text="Back", command=self.show_admin_dashboard).pack(pady=10)

    def show_user_dashboard(self):
        self.clear_screen()
        tk.Label(self.root, text=f"User Dashboard - Welcome, {self.current_user['username']}", font=("Arial", 16)).pack(pady=10)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Book Room", command=self.book_room, width=20).pack(pady=5)
        tk.Button(button_frame, text="View My Bookings", command=self.view_bookings, width=20).pack(pady=5)
        tk.Button(button_frame, text="Logout", command=self.show_login, width=20).pack(pady=20)

    def book_room(self):
        self.clear_screen()
        tk.Label(self.root, text="Book a Room", font=("Arial", 16)).pack(pady=10)

        tk.Label(self.root, text="Room Number").pack()
        room_entry = tk.Entry(self.root)
        room_entry.pack()

        tk.Label(self.root, text="Check-in Date (YYYY-MM-DD)").pack()
        checkin_entry = tk.Entry(self.root)
        checkin_entry.pack()

        tk.Label(self.root, text="Check-out Date (YYYY-MM-DD)").pack()
        checkout_entry = tk.Entry(self.root)
        checkout_entry.pack()

        def book():
            room_number = room_entry.get()
            checkin = checkin_entry.get()
            checkout = checkout_entry.get()
            try:
                datetime.strptime(checkin, "%Y-%m-%d")
                datetime.strptime(checkout, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Invalid date format")
                return

            cursor.execute("INSERT INTO bookings (user_id, room_number, check_in, check_out) VALUES (?, ?, ?, ?)",
                           (self.current_user['id'], room_number, checkin, checkout))
            conn.commit()
            messagebox.showinfo("Success", "Room booked successfully")
            self.show_user_dashboard()

        tk.Button(self.root, text="Book", command=book).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=10)

    def view_bookings(self):
        self.clear_screen()
        tk.Label(self.root, text="My Bookings", font=("Arial", 16)).pack(pady=10)

        tree = ttk.Treeview(self.root, columns=("ID", "Room", "Check-in", "Check-out"), show="headings")
        tree.heading("ID", text="ID")
        tree.heading("Room", text="Room")
        tree.heading("Check-in", text="Check-in")
        tree.heading("Check-out", text="Check-out")
        tree.pack(pady=10)

        cursor.execute("SELECT id, room_number, check_in, check_out FROM bookings WHERE user_id=?", (self.current_user['id'],))
        for row in cursor.fetchall():
            tree.insert("", "end", values=row)

        tk.Button(self.root, text="Cancel Booking", command=lambda: self.cancel_booking(tree)).pack(pady=5)
        tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=10)

    def cancel_booking(self, tree):
        selected = tree.selection()
        if selected:
            booking_id = tree.item(selected[0])['values'][0]
            cursor.execute("DELETE FROM bookings WHERE id=?", (booking_id,))
            conn.commit()
            messagebox.showinfo("Success", "Booking cancelled")
            self.view_bookings()
        else:
            messagebox.showwarning("Warning", "No booking selected")


# Run the app
if __name__ == "__main__":
    root = tk.Tk()
    app = HotelApp(root)
    root.mainloop()
