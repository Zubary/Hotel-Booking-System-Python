import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import json
import os
from datetime import datetime
import csv

# file names used to store data
USERS_FILE = "users.json"
ROOMS_FILE = "rooms.json"
BOOKINGS_FILE = "bookings.json"

# Create default data if files is missing
def initialize_data():
    if not os.path.exists(USERS_FILE):
        users = {
            "admin": {"password": "admin123", "role": "admin"},
            "guest": {"password": "guest123", "role": "guest"}
        }
        with open(USERS_FILE, "w") as f:
            json.dump(users, f, indent=4)

    if not os.path.exists(ROOMS_FILE):
        rooms = {
            "101": {"type": "Single", "price": 100, "available": True},
            "102": {"type": "Double", "price": 150, "available": True},
            "103": {"type": "Suite", "price": 250, "available": True},
        }
        with open(ROOMS_FILE, "w") as f:
            json.dump(rooms, f, indent=4)

    if not os.path.exists(BOOKINGS_FILE):
        with open(BOOKINGS_FILE, "w") as f:
            json.dump({}, f)
# Main application class
class HotelManagementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Hotel Management System")
        self.current_user = None
        self.show_login()
# Clear all widgets from the window
    def clear_screen(self):
        for widget in self.root.winfo_children():
            widget.destroy()
# Load the data from the json file
    def load_data(self, filepath):
        if os.path.exists(filepath):
            with open(filepath, "r") as f:
                return json.load(f)
        return {}
#The command to save the data to JSON File
    def save_data(self, data, filepath):
        with open(filepath, "w") as f:
            json.dump(data, f, indent=4)
#Where the login screen is shown
    def show_login(self):
        self.clear_screen()

        tk.Label(self.root, text="Hotel Management System", font=("Arial", 16)).pack(pady=10)
        tk.Label(self.root, text="Username:").pack()
        username_entry = tk.Entry(self.root)
        username_entry.pack()

        tk.Label(self.root, text="Password:").pack()
        password_entry = tk.Entry(self.root, show="*")
        password_entry.pack()
# The login function
        def login():
            username = username_entry.get()
            password = password_entry.get()

            users = self.load_data(USERS_FILE)
            if username in users and users[username]["password"] == password:
                self.current_user = {
                    "username": username,
                    "role": users[username]["role"]
                }
                if users[username]["role"] == "admin":
                    self.show_admin_dashboard()
                else:
                    self.show_user_dashboard()
            else:
                messagebox.showerror("Login Failed", "Invalid username or password")

        tk.Button(self.root, text="Login", command=login).pack(pady=10)
        tk.Button(self.root, text="Register", command=self.show_register).pack(pady=5)
#Where the registration screen is shown
    def show_register(self):
        self.clear_screen()

        tk.Label(self.root, text="Register New User", font=("Arial", 16)).pack(pady=10)

        tk.Label(self.root, text="Username:").pack()
        username_entry = tk.Entry(self.root)
        username_entry.pack()

        tk.Label(self.root, text="Password:").pack()
        password_entry = tk.Entry(self.root, show="*")
        password_entry.pack()
# Where the user can register
        def register():
            username = username_entry.get()
            password = password_entry.get()

            users = self.load_data(USERS_FILE)
            if username in users:
                messagebox.showerror("Error", "Username already exists!")
            else:
                users[username] = {"password": password, "role": "guest"}
                self.save_data(users, USERS_FILE)
                messagebox.showinfo("Success", "Registration successful!")
                self.show_login()

        tk.Button(self.root, text="Register", command=register).pack(pady=10)
        tk.Button(self.root, text="Back to Login", command=self.show_login).pack(pady=5)

    #The admin dashboard
    def show_admin_dashboard(self):
        self.clear_screen()

        tk.Label(self.root, text=f"Admin Dashboard - Welcome, {self.current_user['username']}", font=("Arial", 16)).pack(pady=10)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Manage Rooms", command=self.manage_rooms, width=20).pack(pady=5)
        tk.Button(button_frame, text="Manage Bookings", command=self.manage_bookings, width=20).pack(pady=5)
        tk.Button(button_frame, text="Generate Reports", command=self.generate_reports, width=20).pack(pady=5)
        tk.Button(button_frame, text="Logout", command=self.show_login, width=20).pack(pady=20)
#Where the admine can manage the rooms
    def manage_rooms(self):
        self.clear_screen()
        rooms = self.load_data(ROOMS_FILE)

        tk.Label(self.root, text="Manage Rooms", font=("Arial", 16)).pack(pady=10)

       
        tree = ttk.Treeview(self.root, columns=("Room", "Type", "Price", "Availability"), show="headings")
        tree.heading("Room", text="Room No.")
        tree.heading("Type", text="Type")
        tree.heading("Price", text="Price ($)")
        tree.heading("Availability", text="Available")

        for room, details in rooms.items():
            tree.insert("", tk.END, values=(room, details["type"], details["price"], "Yes" if details["available"] else "No"))

        tree.pack(pady=10)

        # Buttons for room management
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Add Room", command=self.add_room).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Edit Room", command=lambda: self.edit_room(tree)).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Delete Room", command=lambda: self.delete_room(tree)).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Back", command=self.show_admin_dashboard).pack(side=tk.LEFT, padx=5)
#This feature allows to add room
    def add_room(self):
        room_num = simpledialog.askstring("Add Room", "Enter Room Number:")
        if not room_num:
            return

        room_type = simpledialog.askstring("Add Room", "Enter Room Type (Single/Double/Suite):")
        if not room_type:
            return

        price = simpledialog.askinteger("Add Room", "Enter Price per Night ($):")
        if not price:
            return

        rooms = self.load_data(ROOMS_FILE)
        rooms[room_num] = {"type": room_type, "price": price, "available": True}
        self.save_data(rooms, ROOMS_FILE)
        messagebox.showinfo("Success", f"Room {room_num} added successfully!")
        self.manage_rooms()
#Edit current existing room
    def edit_room(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a room to edit!")
            return

        room_num = tree.item(selected[0])["values"][0]
        rooms = self.load_data(ROOMS_FILE)

        new_type = simpledialog.askstring("Edit Room", "Enter New Room Type:", initialvalue=rooms[room_num]["type"])
        if new_type:
            rooms[room_num]["type"] = new_type

        new_price = simpledialog.askinteger("Edit Room", "Enter New Price:", initialvalue=rooms[room_num]["price"])
        if new_price:
            rooms[room_num]["price"] = new_price

        self.save_data(rooms, ROOMS_FILE)
        messagebox.showinfo("Success", f"Room {room_num} updated!")
        self.manage_rooms()

    def delete_room(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a room to delete!")
            return

        room_num = tree.item(selected[0])["values"][0]
        confirm = messagebox.askyesno("Confirm", f"Delete Room {room_num}?")
        if confirm:
            rooms = self.load_data(ROOMS_FILE)
            del rooms[room_num]
            self.save_data(rooms, ROOMS_FILE)
            messagebox.showinfo("Success", f"Room {room_num} deleted!")
            self.manage_rooms()

    def manage_bookings(self):
        self.clear_screen()
        bookings = self.load_data(BOOKINGS_FILE)

        tk.Label(self.root, text="Manage Bookings", font=("Arial", 16)).pack(pady=10)
       #Treeview to display rooms  
        tree = ttk.Treeview(self.root, columns=("ID", "User", "Room", "Check-in", "Check-out", "Status"), show="headings")
        tree.heading("ID", text="Booking ID")
        tree.heading("User", text="User")
        tree.heading("Room", text="Room")
        tree.heading("Check-in", text="Check-in")
        tree.heading("Check-out", text="Check-out")
        tree.heading("Status", text="Status")

        for booking_id, details in bookings.items():
            tree.insert("", tk.END, values=(
                booking_id,
                details["user"],
                details["room"],
                details["checkin"],
                details["checkout"],
                details["status"].capitalize()
            ))

        tree.pack(pady=10)
       #Buttons for room management
        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Cancel Booking", command=lambda: self.cancel_booking_admin(tree)).pack(side=tk.LEFT, padx=5)
        tk.Button(button_frame, text="Back", command=self.show_admin_dashboard).pack(side=tk.LEFT, padx=5)
    # Cancel booking from admin
    def cancel_booking_admin(self, tree):
        selected = tree.selection()
        if not selected:
            messagebox.showerror("Error", "Please select a booking!")
            return

        booking_id = tree.item(selected[0])["values"][0]
        bookings = self.load_data(BOOKINGS_FILE)
        rooms = self.load_data(ROOMS_FILE)

        if bookings[booking_id]["status"] == "cancelled":
            messagebox.showerror("Error", "Booking already cancelled!")
            return

        bookings[booking_id]["status"] = "cancelled"
        room_num = bookings[booking_id]["room"]
        rooms[room_num]["available"] = True

        self.save_data(bookings, BOOKINGS_FILE)
        self.save_data(rooms, ROOMS_FILE)
        messagebox.showinfo("Success", f"Booking {booking_id} cancelled!")
        self.manage_bookings()
      # This method setups the "Generate Reports" screens in the admin dashboard
      #It provides buttons to generate different types of reports
    def generate_reports(self):
        self.clear_screen()
        tk.Label(self.root, text="Generate Reports", font=("Arial", 16)).pack(pady=10)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="All Bookings Report", command=self.generate_bookings_report, width=20).pack(pady=5)
        tk.Button(button_frame, text="Revenue Report", command=self.generate_revenue_report, width=20).pack(pady=5)
        tk.Button(button_frame, text="Occupancy Report", command=self.generate_occupancy_report, width=20).pack(pady=5)
        tk.Button(button_frame, text="Back", command=self.show_admin_dashboard, width=20).pack(pady=20)
     # This function creates a csv file listing all bookings  
    def generate_bookings_report(self):
        bookings = self.load_data(BOOKINGS_FILE)
        filename = "bookings_report.csv"

        with open(filename, "w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Booking ID", "User", "Room", "Check-in", "Check-out", "Status"])

            for booking_id, details in bookings.items():
                writer.writerow([
                    booking_id,
                    details["user"],
                    details["room"],
                    details["checkin"],
                    details["checkout"],
                    details["status"]
                ])

        messagebox.showinfo("Success", f"Bookings report saved as {filename}!")
      # This function calculates and writes the total revenue from all bookings  
    def generate_revenue_report(self):
        bookings = self.load_data(BOOKINGS_FILE)
        rooms = self.load_data(ROOMS_FILE)
        revenue = 0

        for booking in bookings.values():
            if booking["status"] == "booked":
                room_num = booking["room"]
                revenue += rooms[room_num]["price"]

        filename = "revenue_report.txt"
        with open(filename, "w") as file:
            file.write(f"Total Revenue: ${revenue}\n")
            file.write(f"Total Bookings: {len(bookings)}\n")

        messagebox.showinfo("Success", f"Revenue report saved as {filename}!")
       # This function checks how many rooms are available and calculates the occupancy rate    
    def generate_occupancy_report(self):
        rooms = self.load_data(ROOMS_FILE)
        total_rooms = len(rooms)
        available_rooms = sum(1 for room in rooms.values() if room["available"])

        filename = "occupancy_report.txt"
        with open(filename, "w") as file:
            file.write(f"Total Rooms: {total_rooms}\n")
            file.write(f"Available Rooms: {available_rooms}\n")
            file.write(f"Occupancy Rate: {(total_rooms - available_rooms) / total_rooms * 100:.2f}%\n")

        messagebox.showinfo("Success", f"Occupancy report saved as {filename}!")

    # ================== USER DASHBOARD ==================
    def show_user_dashboard(self):
        self.clear_screen()
        tk.Label(self.root, text=f"Welcome, {self.current_user['username']}", font=("Arial", 16)).pack(pady=10)

        button_frame = tk.Frame(self.root)
        button_frame.pack(pady=10)

        tk.Button(button_frame, text="Book a Room", command=self.book_room, width=20).pack(pady=5)
        tk.Button(button_frame, text="View My Bookings", command=self.view_user_bookings, width=20).pack(pady=5)
        tk.Button(button_frame, text="Logout", command=self.show_login, width=20).pack(pady=20)
    # This function lets a user choose and book an available room
    def book_room(self):
        self.clear_screen()
        rooms = self.load_data(ROOMS_FILE)
        # Filter rooms to only those that are available
        available_rooms = {k: v for k, v in rooms.items() if v["available"]}
        # if no rooms are available show a message and return to dashboard  
        if not available_rooms:
            tk.Label(self.root, text="No rooms available!").pack(pady=10)
            tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=5)
            return

        tk.Label(self.root, text="Book a Room", font=("Arial", 16)).pack(pady=10)

        room_var = tk.StringVar(self.root)
        room_var.set(list(available_rooms.keys())[0])
       
        #Room selection dropdown
        tk.Label(self.root, text="Select Room:").pack()
        tk.OptionMenu(self.root, room_var, *available_rooms.keys()).pack()
       
        #Entry for check in and check out dates
        tk.Label(self.root, text="Check-in (YYYY-MM-DD):").pack()
        checkin_entry = tk.Entry(self.root)
        checkin_entry.pack()

        tk.Label(self.root, text="Check-out (YYYY-MM-DD):").pack()
        checkout_entry = tk.Entry(self.root)
        checkout_entry.pack()
       
        #Inner function to confirm the booking
        def confirm_booking():
            room = room_var.get()
            checkin = checkin_entry.get()
            checkout = checkout_entry.get()
           
            #Validate date format
            try:
                datetime.strptime(checkin, "%Y-%m-%d")
                datetime.strptime(checkout, "%Y-%m-%d")
            except ValueError:
                messagebox.showerror("Error", "Invalid date format! Use YYYY-MM-DD.")
                return

            bookings = self.load_data(BOOKINGS_FILE)
            booking_id = str(len(bookings) + 1)
            bookings[booking_id] = {
                "user": self.current_user["username"],
                "room": room,
                "checkin": checkin,
                "checkout": checkout,
                "status": "booked"
            }

            rooms[room]["available"] = False
            self.save_data(bookings, BOOKINGS_FILE)
            self.save_data(rooms, ROOMS_FILE)

            messagebox.showinfo("Success", f"Room {room} booked successfully!")
            self.show_user_dashboard()

        #Buttons to confirm or cancel bookings
        tk.Button(self.root, text="Confirm Booking", command=confirm_booking).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=5)
    #This function shows the the current users booking in a table and allows cancellation
    def view_user_bookings(self):
        self.clear_screen()
        bookings = self.load_data(BOOKINGS_FILE)
       
        #Filter bookings for current user
        user_bookings = {k: v for k, v in bookings.items() if v["user"] == self.current_user["username"]}

        tk.Label(self.root, text="My Bookings", font=("Arial", 16)).pack(pady=10)
       
        # Show message if no bookings exist
        if not user_bookings:
            tk.Label(self.root, text="No bookings found!").pack(pady=10)
            tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=5)
            return
       
        #Set up treeview table for display bookings
        tree = ttk.Treeview(self.root, columns=("ID", "Room", "Check-in", "Check-out", "Status"), show="headings")
        tree.heading("ID", text="Booking ID")
        tree.heading("Room", text="Room")
        tree.heading("Check-in", text="Check-in")
        tree.heading("Check-out", text="Check-out")
        tree.heading("Status", text="Status")
       
        #Insert booking data into the tree
        for booking_id, details in user_bookings.items():
            tree.insert("", tk.END, values=(
                booking_id,
                details["room"],
                details["checkin"],
                details["checkout"],
                details["status"].capitalize()
            ))

        tree.pack(pady=10)
        # Function to cancel the selected booking
        def cancel_booking():
            selected = tree.selection()
            if not selected:
                messagebox.showerror("Error", "Please select a booking!")
                return

            booking_id = tree.item(selected[0])["values"][0]
            bookings = self.load_data(BOOKINGS_FILE)
            rooms = self.load_data(ROOMS_FILE)
            #Prevent canceling an already cancelled booking
            if bookings[booking_id]["status"] == "cancelled":
                messagebox.showerror("Error", "Booking already cancelled!")
                return

            bookings[booking_id]["status"] = "cancelled"
            room_num = bookings[booking_id]["room"]
            rooms[room_num]["available"] = True

            self.save_data(bookings, BOOKINGS_FILE)
            self.save_data(rooms, ROOMS_FILE)
            messagebox.showinfo("Success", "Booking cancelled!")
            self.view_user_bookings()
       
        #Buttons to cancel booking or go back
        tk.Button(self.root, text="Cancel Booking", command=cancel_booking).pack(pady=10)
        tk.Button(self.root, text="Back", command=self.show_user_dashboard).pack(pady=5)

# Entry point of the app
if __name__ == "__main__":
    initialize_data()
    root = tk.Tk()
    app = HotelManagementApp(root)
    root.mainloop()

